/*  T41_FP_Swbrd_Jig.scad   K9IVB   11/29/2024
    
    This is an assembly jig and eventually a 3D Module to assist in the assembly of the T41 Front Panel Switch Board with 16 pushbutton switches.  The T41 Front panel is 3D printed with a nominal thickness of 3.5mm and a SW board thickness of 1.5mm.
    The PB switches [TS02-66-43-BK-100-LCR-D] are 6x6mm Tactile with a 9mm Actuator Height [above the PCB seating plane] The actuator diameter was measured as 3.05mm @ top and 3.47mm at the top of the switch  will try 1st pass at 4mm 
    
    The cap tops Ref A56 Cap.jpg is 6mm H x  6.2mm D with a 3.5mm D hole for the switch button

*/
//===============================================================================
/*  PCB information
    
   4 Corner mounting holes 3.5052mm D
   Outside dimensions 100mm x 60.96mm (X x Y)
   For  other dimensions refer to K9HZ document or K9IVB's K9HZ_Switch_Matrix_Board_V012.6_dril_file_analysis.xls
   
*/
$fn = 32;
in2mm = 25.4;   // All measurement are in mm
/*  Basic hole and screw information
    The 4-40 uses #30 - 0.1285 drill for clearance
    The 4-40 uses #43 - 0.0890" drill for tap or sheet metal screw  [2.26mm]
    The 4-40 x 0.135 insert uses a hole of 5/32" - 0.15625" or a taper from 
      0.172" to 0.153" in the first 0.135"  & requires  0.25" post for support
    The M3x0.5 uses   3.3mm or #30 - 0.1285" drill for clearance
    The M3x0.5 uses a 2.5mm hole or a #40 drill - 0.0980" for tap or
      sheet metal screw
    The 6-32 uses #25 - 0.1495" drill for clearance 
    The 6-32 uses a #36 - 0.1065" drill for tap or sheet metal screw*/
Num4C = 0.1285*in2mm;    // 4-40 clearance
Num4T = 0.089*in2mm;     // 4-40 threads
Num4HdC = 6;             // #4 Head diameter maximum 0.219" 5.56mm
Num4_insrt = 0.15625*in2mm; // 4-40 insert
M3C = 3.3;               // M3x0.5 clearance
M3T = 2.5;               // M3x0.5 threads
Num6C = 0.1495*in2mm;    // 6-32 clearance
Num6T = 0.1065*in2mm;    // 6-32 threads
PBb = 4; // Push Butten plunger clearance for jig pb sw shaft only
//PBp = 6.5; // Push Butten plunger clearance for A56 button topper
ActHt = 9; // Actuator [PB] height is 9mm.  [8, 9, 10 & 11mm are available]
PCBx = 100; // x dim
PCBy = 60.96; //y dim
Coffset = 4.351; // X & Y equal Corner offset to Mtg hole
PBxOs = 4.895; // Push button X offset to row 1
PByOs = 12.479; // Push button Y offset to row 1
//Pnlz = 3.5; // panel thickness
Pnlz = 2; // panel thickness for assby Jig
Spacer = 4; // PB sw clearance sw body is 3.89 mm high, shaft clear @ 7.5mm
Step1 = 18.001; //PB spacing
Step2 = 17.998;

{
difference()
{
    union()
    {
        cube([PCBx,PCBy,Pnlz]);
        // add the 4 corner posts - see K9HZ Board Dimensions pdf for Numbers
        translate([Coffset,Coffset,0]) cylinder(h=ActHt,d=5);  // BL cnr
        translate([Coffset,Coffset+52.258,0]) cylinder(h=ActHt,d=5);  // BR
        translate([Coffset+91.228,Coffset,0]) cylinder(h=ActHt,d=5);  // TL
        translate([Coffset+91.228,Coffset+52.258,0]) cylinder(h=ActHt,d=5);// //TR
        // add the two corner extensions to key into board
        translate([Coffset,Coffset+52.258,8]) cylinder(h=4,d=M3T);  // BR 3mm screw
        translate([Coffset+91.228,Coffset,8]) cylinder(h=4,d=M3T);  // TL 3mm screw
    }
        // Remove the 2 mounting holes
        translate([Coffset,Coffset,5]) cylinder(h=ActHt,d=Num4T);  // BL cnr
        translate([Coffset+91.228,Coffset+52.258,5]) cylinder(h=ActHt,d=Num4T);// //TR
        // Remove 16 alignment holes for the PB sw's
        translate([PBxOs,PByOs,-3]) cylinder(h=ActHt,d=PBb);  // BL
        translate([PBxOs,PByOs+Step1,-3]) cylinder(h=ActHt,d=PBb);  // BM
        translate([PBxOs,PByOs+2*Step1,-3]) cylinder(h=ActHt,d=PBb);  // BR
        
        translate([PBxOs+Step1,PByOs,-3]) cylinder(h=ActHt,d=PBb);  // R2L 
        translate([PBxOs+Step1+Step1,PByOs,-3]) cylinder(h=ActHt,d=PBb);  // R3L        
        translate([PBxOs+Step1+Step1+Step2,PByOs,-3]) cylinder(h=ActHt,d=PBb);  // R4L
        translate([PBxOs+Step1+Step1+Step2+Step1,PByOs,-3]) cylinder(h=ActHt,d=PBb);  // R5L    
        translate([PBxOs+Step1+Step1+Step2+Step1+Step2,PByOs,-3]) cylinder(h=ActHt,d=PBb);  // R6L
    
    translate([PBxOs+Step1,PByOs+Step1,-3]) cylinder(h=ActHt,d=PBb);  // R2M 
        translate([PBxOs+Step1+Step1,PByOs+Step1,-3]) cylinder(h=ActHt,d=PBb);  // R3M        
        translate([PBxOs+Step1+Step1+Step2,PByOs+Step1,-3]) cylinder(h=ActHt,d=PBb);  // R4M
        translate([PBxOs+Step1+Step1+Step2+Step1,PByOs+Step1,-3]) cylinder(h=ActHt,d=PBb);  // R5M    
        translate([PBxOs+Step1+Step1+Step2+Step1+Step2,PByOs+Step1,-3]) cylinder(h=ActHt,d=PBb);  // R6M
    
    translate([PBxOs+Step1,PByOs+2*Step1,-3]) cylinder(h=ActHt,d=PBb);  // R2R 
        translate([PBxOs+Step1+Step1,PByOs+2*Step1,-3]) cylinder(h=ActHt,d=PBb);  // R3R        
        translate([PBxOs+Step1+Step1+Step2,PByOs+2*Step1,-3]) cylinder(h=ActHt,d=PBb);  // R4R
        translate([PBxOs+Step1+Step1+Step2+Step1,PByOs+2*Step1,-3]) cylinder(h=ActHt,d=PBb);  // R5R    
        translate([PBxOs+Step1+Step1+Step2+Step1+Step2,PByOs+2*Step1,-3]) cylinder(h=ActHt,d=PBb);  // R6R
    
}

}