Elecraft K3 small knobs by pa5ca on Thingiverse: https://www.thingiverse.com/thing:7274698

Summary:
This is my contribution to the 3d printing community.I have drawn  these knobs in FreeCad.A friend of me owns a older version K3, early serial number and the knobs, specially the smaller ones 4 in a quadrant crack.So I hope that I can contribute also to the K3 community.Yours,Frans (PA5CA)