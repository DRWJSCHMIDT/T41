
Pocket AVR Programmer Drivers
=============================

Folder Contents
-------------------
Windows 7, 8, 8.1, 10 Driver files for the AVR Pocket Programmer. Original Source of files: http://www.adafruit.com/downloads/usbtiny_signed_8.zip

Please note you no longer need to verify the security signature for the drivers.

