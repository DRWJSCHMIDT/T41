#ifndef BEENHERE
#define BEENHERE

//======================================== User section that might need to be changed ===================================
#define VERSION                     "V050.0"                              // Change this for updates. If you make this longer than 9 characters, brace yourself for surprises
#define UPDATE_SWITCH_MATRIX        0                                     // 1 = Yes, redo the switch matrix values, 0 = leave switch matrix values as is from the last change
struct maps {
  char mapNames[50];
  float lat;
  float lon;
};
extern struct maps myMapFiles[];


//======================================== Library include files ========================================================
#include <Adafruit_GFX.h>
#include "Adafruit_MCP23X17.h"
#include "Fonts/FreeMonoBold24pt7b.h"
#include "Fonts/FreeMonoBold18pt7b.h"
#include "Fonts/FreeMono24pt7b.h"
#include "Fonts/FreeMono9pt7b.h"
//#include <Audio.h>                                  //https://github.com/chipaudette/OpenAudio_ArduinoLibrary
//#include <OpenAudio_ArduinoLibrary.h>               // AFP 11-01-22
#include <TimeLib.h>                                // Part of Teensy Time library
#include <Wire.h>
#include <SPI.h>
#include <SD.h>
#include <Metro.h>
#include <Bounce.h>
#include <arm_math.h>
#include <arm_const_structs.h>
// ============ AFP 09-04-23 #include modified Si5351 library
// == Modified Si linbrary must be included in folder with T41 code
#include "si5351.h"
//#include <si5351.h>                                 // https://github.com/etherkit/Si5351Arduino
#include <RA8875.h>                                 // https://github.com/mjs513/RA8875/tree/RA8875_t4
#include <Rotary.h>                                 // https://github.com/brianlow/Rotary
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <util/crc16.h>                             // mdrhere
//#include <utility/imxrt_hw.h>                       // for setting I2S freq, Thanks, FrankB!
#include <EEPROM.h>

#include <math.h>


//========================================= Display pins
#define BACKLIGHT_PIN               6     // unfortunately connected to 3V3 in DO7JBHs PCB 
#define TFT_DC                      9
#define TFT_CS                      10
#define TFT_MOSI                    11
#define TFT_MISO                    12
#define TFT_SCLK                    13
#define TFT_RST                     255


#define RA8875_CS                   TFT_CS
#define RA8875_RESET                TFT_DC  // any pin or nothing!

#define WIGGLE_ROOM                  20     // This is the maximum value that can added to a BUSY_ANALOG_PIN pin read value of a push


//======================================== Symbolic Constants for the T41 ===================================================
#define RIGNAME                     "T41-EP SDT"
#define NUMBER_OF_SWITCHES          18              // Number of push button switches. 16 on older boards
#define TOP_MENU_COUNT              14             // Menus to process AFP 09-27-22, JJP 7-8-23 AFP 04-12-24
#define RIGNAME_X_OFFSET            570             // Pixel count to rig name field                                       // Says we are using a Teensy 4 or 4.1
#define RA8875_DISPLAY              1               // Comment out if not using RA8875 display
#define TEMPMON_ROOMTEMP            25.0f
//#define SD_CARD_PRESENT             1               // 1 if SD present, 0 otherwise       //   JJP  7/18/23
#define SD_CS                       BUILTIN_SDCARD  // Works on T_3.6 and T_4.1 ...
#define MAX_SD_ITEMS                184             // Number of discrete data items written to EEPROM

//#define STORE_SWITCH_VALUES                       // Uncomment to save the analog switch values for your push button matrix

#define OFF                         0
#define ON                          1

//================================ mapping globals and Symbolic constants ================
#define BUFFPIXEL                   20  // Use buffer to read image rather than 1 pixel at a time

#define DEGREES2RADIANS             0.01745329
#define RADIANS2DEGREES             57.29578
#define PI_BY_180                   0.01745329
#define VALID_EEPROM_DATA           1
#define INVALID_EEPROM_DATA         0


// ================== Use one of the following encoder configurations. Set in MyConfiguratonFile.h
//=================== Encoder pins  Jack Purdum W8TEE September 25, 2023
#ifdef FOURSQRP
    #define VOLUME_ENCODER_A          2
    #define VOLUME_ENCODER_B          3
    #define FILTER_ENCODER_A         16
    #define FILTER_ENCODER_B         15
    #define FINETUNE_ENCODER_A        4
    #define FINETUNE_ENCODER_B        5
    #define TUNE_ENCODER_A           14
    #define TUNE_ENCODER_B           17
#else
    #define VOLUME_ENCODER_A         2//5   //2
    #define VOLUME_ENCODER_B         3//4   //3
    #define FILTER_ENCODER_A         15
    #define FILTER_ENCODER_B         14
    #define FINETUNE_ENCODER_A       4//17  // 4
    #define FINETUNE_ENCODER_B       5//16  // 5
    #define TUNE_ENCODER_A           17//2  //16
    #define TUNE_ENCODER_B           16//3  // 17
#endif
//
//#define DEBUG_JACK
//#define DEBUG1
//#define DEBUG2
//#define DEBUG3
//#define DEBUG4
//#define DEBUG6
//#define DEBUG7
//#define DEBUG8
//#define DEBUG9
#define NUMBER_OF_ELEMENTS(x) (sizeof(x)/sizeof(x[0]))  // Typeless way to find number of elements in the x[] array
#define NEW_SI5351_FREQ_MULT    1UL


//======================================== Symbolic constants ==========================================================

// These constants are used by the voltage divider network so only 1 analog pin is used for the 16 option switches. These may need
// to be changed for the exact value for your system. They are initialized in the INO file.

#define BUSY_ANALOG_PIN              39     // This is the analog pin that controls the 18 switches
#define NOTHING_TO_SEE_HERE         950     // If the analog pin is greater than this value, nothing's going on
#define BOGUS_PIN_READ               -1     // If no push button read

//                                             button and still have the switch value be associated with the correct push button.
#define SWITCH_DEBOUNCE_DELAY       50L     // Milliseconds for the switch to settle down
#define AUDIO_PLOT_CEILING          119     // (SPECTRUM_BOTTOM - AUDIO_SPECTRUM_TOP)

#define MAX_FAVORITES                13     // Max number of favorite frequencies stored in EEPROM

#define PRIMARY_MENU                  0
#define SECONDARY_MENU                1
#define SELECTED_INDEX                3     // This is the index for MENU_OPTION_SELECT
#define PRIMARY_MENU_X                0
#define SECONDARY_MENU_X              250
#define MENUS_Y                       0
#define EACH_MENU_WIDTH               260
#define BOTH_MENU_WIDTHS             (EACH_MENU_WIDTH * 2 + 30)


#define MENU_OPTION_SELECT           0     // Switches changed for new menu system JJP 3/10/24
#define MAIN_MENU_UP                 1
#define BAND_UP                      2
#define ZOOM                         3
#define RESET_TUNING                 4   
#define BAND_DN                      5
#define SET_MODE                     6
#define DEMODULATION                 7
#define MAIN_TUNE_INCREMENT          8
#define NOISE_REDUCTION              9
#define NOTCH_FILTER                10
#define FINE_TUNE_INCREMENT         11
#define FILTER                      12
#define DECODER_TOGGLE              13
#define UNUSED_1                    14
#define UNUSED_2                    15
#define UNUSED_3                    16
#define UNUSED_4                    17

#define MENU_BAILOUT_VALUE          17    // Used to exit from main menu list 


/*
#define MENU_OPTION_SELECT           0     // These are the expected values from the switch ladder
#define MAIN_MENU_UP                 1
#define BAND_UP                      2
#define ZOOM                         3
#define MAIN_MENU_DN                 4
#define BAND_DN                      5
#define FILTER                       6
#define DEMODULATION                 7
#define SET_MODE                     8
#define NOISE_REDUCTION              9
#define NOTCH_FILTER                10
#define NOISE_FLOOR                 11
#define FINE_TUNE_INCREMENT         12
#define DECODER_TOGGLE              13
#define MAIN_TUNE_INCREMENT         14
#define RESET_TUNING                15    // AFP 10-11-22
#define UNUSED_1                    16    // AFP 10-11-22
#define BEARING                     17    // AFP 10-11-22
*/
//=======================================================
#define XPIXELS                     800           // This is for the 5.0" display
#define YPIXELS                     480
#define PIXELHEIGHT                  20           // Used in fillRec() to erase a line
#define CHAR_HEIGHT                  32
#define PIXELS_PER_EQUALIZER_DELTA   10           // Number of pixeks per detent of encoder for equalizer changes
#define PIXELS_PER_AUDIO_DELTA       10

#define SPECTRUM_LEFT_X       3            // Used to plot left edge of spectrum display  AFP 12-14-21
#define WATERFALL_LEFT_X      SPECTRUM_LEFT_X
#define SPECT_RES_92          512/92000

#define CLIP_AUDIO_PEAK       115           // The pixel value where audio peak overwrites S-meter
#define SPECTRUM_RES          512
#define SPECTRUM_TOP_Y        100           // Start of spectrum plot space
#define SPECTRUM_HEIGHT       150           // This is the pixel height of spectrum plot area without disturbing the axes
#define SPECTRUM_BOTTOM       (SPECTRUM_TOP_Y + SPECTRUM_HEIGHT - 3)        // 247 = 100 + 150 - 3
#define AUDIO_SPECTRUM_TOP    129
#define AUDIO_SPECTRUM_BOTTOM SPECTRUM_BOTTOM
#define MAX_WATERFALL_WIDTH   512           // Pixel width of waterfall
#define MAX_WATERFALL_ROWS    170           // Waterfall rows

#define WATERFALL_RIGHT_X     (WATERFALL_LEFT_X + MAX_WATERFALL_WIDTH)      // 3 + 512
#define WATERFALL_TOP_Y       (SPECTRUM_TOP_Y + SPECTRUM_HEIGHT + 5)        // 130 + 120 + 5 = 255
#define FIRST_WATERFALL_LINE  (WATERFALL_TOP_Y + 20)                        // 255 + 35 = 290
#define WATERFALL_BOTTOM      (FIRST_WATERFALL_LINE + MAX_WATERFALL_ROWS)   // 290 + 170 = 460
#define TEMP_X_OFFSET         15
#define TEMP_Y_OFFSET         465                                           // 480 * 0.97 = 465
#define AGC_Y_OFFSET          292
#define AGC_X_OFFSET          680
#define VOLUME_Y_OFFSET       180
#define INCREMENT_X           WATERFALL_RIGHT_X + 25
#define INCREMENT_Y           WATERFALL_TOP_Y   + 70
#define SPECTRUMCORNER_X      INCREMENT_X
#define SPECTRUMCORNER_Y      INCREMENT_Y
#define INFORMATION_WINDOW_X  WATERFALL_RIGHT_X + 25                        // 512 + 25 = 537
#define INFORMATION_WINDOW_Y  WATERFALL_TOP_Y + 37                          // 255 + 37 = 292
#define BAND_INDICATOR_X      WATERFALL_RIGHT_X + 25
#define BAND_INDICATOR_Y      WATERFALL_TOP_Y + 37                          // 292
#define OPERATION_STATS_X     130
#define OPERATION_STATS_Y     75
#define BAND_SUMMARY_X        BAND_INDICATOR_X
#define BAND_SUMMARY_Y        150
#define START_BAND_DATA_X     TEMP_X_OFFSET
#define START_BAND_DATA_Y     YPIXELS * 0.25

#define X_R_STATUS_X          730
#define X_R_STATUS_Y          70
#define RECEIVE_STATE         1
#define TRANSMIT_STATE        0

#define SMETER_X              WATERFALL_RIGHT_X + 16
#define SMETER_Y              YPIXELS * 0.22                // 480 * 0.22 = 106
#define SMETER_BAR_HEIGHT     18
#define SMETER_BAR_LENGTH     180
#define SPECTRUM_NOISE_FLOOR  (SPECTRUM_TOP_Y + SPECTRUM_HEIGHT - 3)
#define TIME_X                (XPIXELS * 0.73)                            // Upper-left corner for time
#define TIME_Y                (YPIXELS * 0.07)
#define WHICH_SIDEBAND_X      (XPIXELS * 0.70)
#define WHICH_SIDEBAND_Y      (YPIXELS * 0.20)
#define FILTER_PARAMETERS_X   (XPIXELS * 0.22)
#define FILTER_PARAMETERS_Y   (YPIXELS * 0.213)
#define DEFAULT_EQUALIZER_BAR 100                                         // Default equalizer bar height
#define FREQUENCY_X           5
#define FREQUENCY_Y           45
#define FREQUENCY_X_SPLIT     280
#define VFO_A                 0
#define VFO_B                 1
#define VFO_SPLIT             2
#define VFOA_PIXEL_LENGTH     275
#define VFOB_PIXEL_LENGTH     280
#define FREQUENCY_PIXEL_HI    45
#define SPLIT_INCREMENT       500L
//                                                            Offsets for status info
#define FIELD_OFFSET_X        WATERFALL_RIGHT_X + 118                     // X coordinate for field
#define NOTCH_X               WATERFALL_RIGHT_X + 58
#define NOTCH_Y               WATERFALL_TOP_Y   + 90
#define NOISE_REDUCE_X        WATERFALL_RIGHT_X + 58
#define NOISE_REDUCE_Y        WATERFALL_TOP_Y   + 110

//#define AGC_Y_OFFSET          292
//#define AGC_X_OFFSET          680

#define ZOOM_X                705
#define ZOOM_Y                365
//#define RF_GAIN_X             681
//#define RF_GAIN_Y             365
#define RF_GAIN_X             681
#define RF_GAIN_Y             WATERFALL_TOP_Y   + 90

#define EQUALIZATION_X        WATERFALL_RIGHT_X + 35
#define EQUALIZATION_Y        WATERFALL_TOP_Y   + 130
#define SD_X                  707
#define SD_Y                  385
#define COMPRESSION_X         WATERFALL_RIGHT_X + 33
#define COMPRESSION_Y         WATERFALL_TOP_Y   + 150
#define DECODER_X             WATERFALL_RIGHT_X + 43                      // 512 +  43 = 555
#define DECODER_Y             WATERFALL_TOP_Y   + 190                     // 255 + 190 = 345
#define WPM_X                 WATERFALL_RIGHT_X + 58
#define WPM_Y                 WATERFALL_TOP_Y   + 170
#define NR_X_OFF              WATERFALL_RIGHT_X + 80
#define NR_Y_OFF              WATERFALL_TOP_Y   + 190
#define VOLUME_INFO_FIELD_X   540
#define VOLUME_INFO_FIELD_Y   292

#define SAM_PLL_HILBERT_STAGES                 7      // AFP 11-02-22
#define OUT_IDX   (3 * SAM_PLL_HILBERT_STAGES)        // AFP 11-02-22
#define MAX_DECODE_CHARS        32                    // Max chars that can appear on decoder line.  Increased to 32.  KF5N October 29, 2023
#define DECODER_BUFFER_SIZE     128                   // Max chars in binary search string with , . ?
#define DECODER_CAP_VALUE       6.0
#define DITLENGTH_DELTA         5                     // Number of milliseconds to change ditLEngth with encoder
#define HISTOGRAM_ELEMENTS      750
#define LOWEST_ATOM_TIME         20                   // 60WPM has an atom of 20ms
#define HIGHEST_ATOM_TIME       240                   // 5WPM has an atom of 240ms                              
#define DIT_WEIGHT              0.3                   // Previous values account for 90% of average
#define AVERAGE_DIT_WEIGHT      0.7                   // The number above and this one must equal 1.0
#define DITLENGTH_OBSERVATIONS  10                    // Number of ditlength observations to compute average
#define ADAPTIVE_SCALE_FACTOR   0.8                   // The amount of old histogram values are presesrved
#define SCALE_CONSTANT          (1.0 / (1.0 - ADAPTIVE_SCALE_FACTOR)) // Insure array has enough observations to scale
#define FILTER_WIDTH            25                    // The default filter highlight in spectrum displah
#define ZOOM_2X_BIN_COUNT       187.5                 // The 2x bin count for display
#define MAX_AUDIO_VOLUME        100
#define MIN_AUDIO_VOLUME         16                   //yours might be different. On my rig, this is where the band noise disappears.

#define AUDIO_POST_PROCESSOR_BANDS  8                     // Number of audio segments
#define EEPROM_FAVORITES_X          100
#define EEPROM_FAVORITES_Y          50
#define BANDWIDTH_INDICATOR_Y       SPECTRUM_BOTTOM
#define FAST_TUNE_CENTERLINE        ((MAX_WATERFALL_WIDTH + SPECTRUM_LEFT_X+6) / 2)

#define DO_NOTHING              -1

#define FLOAT_PRECISION          6                 // Assumed precision for a float
#define BUFFER_SINE_COUNT        8                 // Leads to a 750Hz signal

#define EQUALIZER_CELL_COUNT    14
#define AUDIO_CELL_COUNT         8

#define USE_LOG10FAST

#define MP3
#define TEMPMON_ROOMTEMP 25.0f
#define ENCODER_DELAY             100L        // Menu options scroll too fast!

//--------------------- decoding stuff
#define FFT_LENGTH                512
#define NOISE_SAMPLE_SIZE         500
#define SD_MULTIPLIER             3
#define NOISE_MULTIPLIER          0.5         // Signal must be this many time greater than the noise floor
#define STARTING_DITLENGTH        80          // dit length for 15wpm

#define  BLACK                    0x0000      /*   0,   0,   0 */
#define  RA8875_BLUE              0x000F      /*   0,   0, 128 */
#define  DARK_GREEN               0x03E0      /*   0, 128,   0 */
#define  DARKCYAN                 0x03EF      /*   0, 128, 128 */
#define  MAROON                   0x7800      /* 128,   0,   0 */
#define  PURPLE                   0x780F      /* 128,   0, 128 */
#define  OLIVE                    0x7BE0      /* 128, 128,   0 */
#define  RA8875_LIGHT_GREY        0xC618      /* 192, 192, 192 */

#define  DARK_RED                 tft.Color565(64,0,0)
#define  DARKGREY                 0x7BEF      /* 128, 128, 128 */
#define  BLUE                     0x001F      /*   0,   0, 255 */
#define  RA8875_GREEN             0x07E0      /*   0, 255,   0 */
#define  CYAN                     0x07FF      /*   0, 255, 255 */
#define  RED                      0xF800      /* 255,   0,   0 */
#define  MAGENTA                  0xF81F      /* 255,   0, 255 */
#define  YELLOW                   0xFFE0      /* 255, 255,   0 */
#define  WHITE                    0xFFFF      /* 255, 255, 255 */
#define  ORANGE                   0xFD20      /* 255, 165,   0 */
#define  RA8875_GREENYELLOW       0xAFE5      /* 173, 255,  47 */
#define  PINK                     0xF81F
#define  FILTER_WIN               0x10       // Color of SSB filter width


#ifndef FLASHMEM
#define FLASHMEM
#endif

//#include <utility/imxrt_hw.h> // for setting I2S freq, Thanks, FrankB!
#define WFM_SAMPLE_RATE             256000.0f

//#define TIMEZONE                    "EST: "     // Set for eastern time

//#define DEFAULTFREQINCREMENT        1000L       //Values 10, 50, 100, 250, 1000, 10000  AFP 09-26-22
//#define FAST_TUNE_INCREMENT         50L
#define DEFAULTFREQINDEX            4           //  Index 10Hz=> 0, 50Hz=> 1, 100Hz=> 2, 250Hz=> 3, 
                                                //  1000Hz=> 4, 10000Hz=> 5, 100000=> 6, 1000000=> 7 
#define MAX_FREQ_INDEX              8
#define TEMPMON_ROOMTEMP            25.0f
#define MAX_WPM                     60
#define MAX_TONE                    1000
#define MIN_TONE                    300

#define ENCODER_FACTOR              0.25F        // use 0.25f with cheap encoders that have 4 detents per step, 
//                                                  for other encoders or libs we use 1.0f
#define MAX_ZOOM_ENTRIES            5
//#define FREQ_SEP_CHARACTER          ','

//========================================================= Pin Assignments =====================================
//========================================= Pins 0 and 1 are usually reserved for the USB COM port communications
//========================================= On the Teensy 4.1 board, pins GND, 0-12, and pins 13-23, 3.3V, GND, and
//========================================= Vin are "covered up" by the Audio board. However, not all of those pins are
//========================================= actually used by the board. See: https://www.pjrc.com/store/teensy3_audio.html

//========================================= Display pins
#define BACKLIGHT_PIN               6     // unfortunately connected to 3V3 in DO7JBHs PCB 
#define TFT_DC                      9
#define TFT_CS                      10
#define TFT_MOSI                    11
#define TFT_MISO                    12
#define TFT_SCLK                    13
#define TFT_RST                     255

//========================================= Filter Board pins
#define FILTERPIN80M                30    // 80M filter relay
#define FILTERPIN40M                31    // 40M filter relay
#define FILTERPIN20M                28    // 20M filter relay
#define FILTERPIN15M                29    // 15M filter relay
#define RXTX                        22    // Transmit/Receive
#define PTT                         37    // Transmit/Receive
#define MUTE                        38    // Mute Audio,  HIGH = "On" Audio available from Audio PA, LOW = Mute audio
//========================================= Switch pins
#define BAND_MENUS                  100    // encoder2 button = button3SW
#define BAND_PLUS                   101    // BAND+ = button2SW
#define CHANGE_INCREMENT            102    // this is the pushbutton pin of the tune encoder
#define CHANGE_FILTER               103    // this is the pushbutton pin of the filter encoder
#define CHANGE_MODE                 104    // Change mode
#define CHANGE_MENU2                105    // this is the pushbutton pin of encoder 3
#define MENU_MINUS                  106    // Menu decrement
#define MENU_PLUS                   107    // this is the menu button pin
#define CHANGE_NOISE                108    // this is the pushbutton pin of NR
#define CHANGE_DEMOD                109    // this is the push button for demodulation
#define CHANGE_ZOOM                 110    // Push button for display zoom feature
#define SET_FREQ_CURSOR             111    // Push button for frequency Cursor feature  was 39 for Al

#define NO_MENUS_ACTIVE             0      // No menus displayed 
#define PRIMARY_MENU_ACTIVE         1      // A primary menu is active
#define SECONDARY_MENU_ACTIVE       2      // Both primary and secondary menus active

//========================================= Keyer pins
#define KEYER_DAH_INPUT_RING         35    // Ring connection for keyer  -- default for righthanded user
#define KEYER_DIT_INPUT_TIP          36    // Tip connection for keyer

#define OPTO_OUTPUT                  24    // To optoisolator and keyed circuit
#define STRAIGHT_KEY                  0
#define KEYER                         1
#define KEYONTIME                   500 // AFP17-22 key on time
//========================================================= End Pin Assignments =================================
//===============================================================================================================

#define TMS0_POWER_DOWN_MASK        (0x1U)
#define TMS0_POWER_DOWN_SHIFT       (0U)
#define TMS1_MEASURE_FREQ(x)        (((uint32_t)(((uint32_t)(x)) << 0U)) & 0xFFFFU)
#define TMS0_ALARM_VALUE(x)         (((uint32_t)(((uint32_t)(x)) << 20U)) & 0xFFF00000U)
#define TMS02_LOW_ALARM_VALUE(x)    (((uint32_t)(((uint32_t)(x)) << 0U)) & 0xFFFU)
#define TMS02_PANIC_ALARM_VALUE(x)  (((uint32_t)(((uint32_t)(x)) << 16U)) & 0xFFF0000U)
//#define MAX_NUMCOEF                 (FFT_LENGTH / 2) + 1    // This is alread defined in AudioFilterConvolution_F32.h at line 110     

#undef  round
#undef  PI
#undef  HALF_PI
#undef  TWO_PI
#define PI                          3.1415926535897932384626433832795f
#define HALF_PI                     1.5707963267948966192313216916398f
#define TWO_PI                      6.283185307179586476925286766559f
#define TPI                         TWO_PI
#define PIH                         HALF_PI
#define FOURPI                      (2.0f * TPI)
#define SIXPI                       (3.0f * TPI)
#define Si_5351_clock               SI5351_CLK2
#define Si_5351_crystal             25000000L
#define MASTER_CLK_MULT             4ULL                                         // QSD frontend requires 4x clock
#define WITHTERM                    1
#define SIGNAL_TAU                  0.1
#define ONEM_SIGNAL_TAU             (1.0 - SIGNAL_TAU)

#define CW_TIMEOUT                  3                                         // Time, in seconds, to trigger display of last Character received
#define ONE_SECOND                  (12000 / cw_decoder_config.blocksize)     // sample rate / decimation rate / block size

#define SSB_MODE                    0
#define CW_MODE                     1
#define RECEIVE_MODE                2

#define SSB_RECEIVE                 0
#define SSB_XMIT                    1
#define CW_RECEIVE                  2
#define CW_XMIT                     3
//  This second set of states are for the loop() modal state machine.
#define SSB_RECEIVE_STATE 0
#define SSB_TRANSMIT_STATE 1
#define CW_RECEIVE_STATE 2
#define CW_TRANSMIT_STRAIGHT_STATE 3
#define CW_TRANSMIT_KEYER_STATE 4
extern int radioState, lastState;  // Used by the loop to monitor current state.

#define DECODER_STATE               0               // 0 = off, 1 = on
#define DECODE_OFF                  0
#define DECODE_ON                   1

#define DIGIMODE_OFF                0
#define CW                          1
#define EFR                         3
#define DCF77                       5

#define SPECTRUM_ZOOM_MIN           0
#define SPECTRUM_ZOOM_1             0
#define SPECTRUM_ZOOM_2             1
#define SPECTRUM_ZOOM_4             2
#define SPECTRUM_ZOOM_8             3
#define SPECTRUM_ZOOM_16            4

#define SPECTRUM_ZOOM_MAX           4

#define SAMPLE_RATE_MIN             6
#define SAMPLE_RATE_8K              0
#define SAMPLE_RATE_11K             1
#define SAMPLE_RATE_16K             2
#define SAMPLE_RATE_22K             3
#define SAMPLE_RATE_32K             4
#define SAMPLE_RATE_44K             5
#define SAMPLE_RATE_48K             6
#define SAMPLE_RATE_50K             7
#define SAMPLE_RATE_88K             8
#define SAMPLE_RATE_96K             9
#define SAMPLE_RATE_100K            10
#define SAMPLE_RATE_101K            11
#define SAMPLE_RATE_176K            12
#define SAMPLE_RATE_192K            13
#define SAMPLE_RATE_234K            14
#define SAMPLE_RATE_256K            15
#define SAMPLE_RATE_281K            16 // ??
#define SAMPLE_RATE_353K            17
#define SAMPLE_RATE_MAX             15

#define TEMPMON_ROOMTEMP 25.0f

#define DEMOD_MIN                   0
#define DEMOD_USB                   0
#define DEMOD_LSB                   1
#define DEMOD_AM                    2
#define DEMOD_SAM                   3
#define DEMOD_MAX                   3 // AFP 11-03-22

#define DEMOD_IQ                    4
#define DEMOD_DCF77                 29        // set the clock with the time signal station DCF77
#define BROADCAST_BAND              0
#define HAM_BAND                    1
#define MISC_BAND                   2
#define BUFFER_SIZE                 128

#define NOTCHPOS                    spectrum_y + 6
#define NOTCHL                      15
#define NOTCHCOLOUR                  RA8875_YELLOW

// Menus !
#define MENU_F_HI_CUT               0
#define MENU_SPECTRUM_ZOOM          1
#define MENU_SAMPLE_RATE            2
#define MENU_SAVE_EEPROM            3
#define MENU_LOAD_EEPROM            4
#define MENU_LPF_SPECTRUM           5
#define MENU_SPECTRUM_OFFSET        6
#define MENU_SPECTRUM_DISPLAY_SCALE 7

#define MENU_IQ_AMPLITUDE           8
#define MENU_IQ_PHASE               9
#define MENU_CALIBRATION_FACTOR     10
#define MENU_CALIBRATION_CONSTANT   11
#define MENU_TIME_SET               12
#define MENU_RESET_CODEC            13
#define MENU_SHOW_SPECTRUM          14

#define FIRST_MENU                  0
#define LAST_MENU                   16   //=================== AFP 04-12-24 V012 RF Atten Plot
#define START_MENU                  0

#define MENU_RF_GAIN                15
#define MENU_RF_ATTENUATION         16
#define MENU_BASS                   17
#define MENU_MIDBASS                18
#define MENU_MID                    19
#define MENU_MIDTREBLE              20
#define MENU_TREBLE                 21
#define MENU_NOTCH_1                25
#define MENU_NOTCH_1_BW             26
#define MENU_AGC_MODE               27
#define MENU_AGC_THRESH             28
#define MENU_AGC_DECAY              29
#define MENU_AGC_SLOPE              30
#define MENU_ANR_NOTCH              31
#define MENU_ANR_TAPS               32
#define MENU_ANR_DELAY              33
#define MENU_ANR_MU                 34
#define MENU_ANR_GAMMA              35
#define MENU_NB_THRESH              36
#define MENU_NB_TAPS                37
#define MENU_NB_IMPULSE_SAMPLES     38
#define MENU_BIT_NUMBER             39
#define MENU_F_LO_CUT               40
#define MENU_NR_PSI                 41
#define MENU_NR_ALPHA               42
#define MENU_NR_BETA                43
#define MENU_NR_USE_X               44
#define MENU_NR_USE_KIM             45

#define MENU_LMS_NR_STRENGTH        46
#define MENU_CPU_SPEED              47
#define MENU_USE_ATAN2              48
#define MENU_NR_KIM                 49

#define MENU_NR_SP                  50
#define MENU_NR_LMS1                51
#define MENU_NR_LMS2                52
#define MENU_NR_OFF                 53

#define FIRST_MENU2                 15
#define LAST_MENU2                  53

// AGC
#define AGC_OPTIONS                 6                 // Six options, 0 - 5
#define MAX_SAMPLE_RATE             (24000.0)
#define MAX_N_TAU                   (8)
#define MAX_TAU_ATTACK              (0.01)
#define RB_SIZE                     (int) (MAX_SAMPLE_RATE * MAX_N_TAU * MAX_TAU_ATTACK + 1)

//#define CONFIG_VERSION              "mr1"             //mdrhere ID of the E settings block, change if structure changes
//#define CONFIG_START 0                                // Address start the EEPROM data. (emulated with size of 4K. Actual address managed in library)

//#define TERMCHRXWIDTH               9                     // print stuff for text terminal
//#define TERMCHRYWIDTH               10
//#define TERMNROWS                   4                     // 15 
//#define TERMNCOLS                   28                    // 34 

#define CW_TEXT_START_X             5
#define CW_TEXT_START_Y             449                   // 480 * 0.97 = 465 - height = 465 - 16 = 449
#define CW_MESSAGE_WIDTH            MAX_WATERFALL_WIDTH   // 512
#define CW_MESSAGE_HEIGHT           16                    // tft.getFontHeight()

//#ifdef USE_W7PUA

#define BAND_80M                  0
#define BAND_40M                  1
#define BAND_20M                  2
#define BAND_17M                  3
#define BAND_15M                  4
#define BAND_12M                  5
#define BAND_10M                  6

#define FIRST_BAND                BAND_80M
#define LAST_BAND                 BAND_10M    //AFP 1-28-21
#define NUMBER_OF_BANDS           7           //AFP 1-28-21
//#define STARTUP_BAND              BAND_40M    //AFP 1-28-21

//#endif

//=== CW Filter ===


extern Adafruit_MCP23X17 mcp;

//======================================== Globals =========================================
extern RA8875 tft; 

extern volatile int16_t curVal[];
extern volatile int16_t oldVal[];
extern const int16_t posx[];
extern const int16_t posy[];
extern const int16_t radius[];
//const uint8_t analogIn[6] = {A0, A1, A2, A3, A8, A9};
extern const uint16_t needleColors[];
extern const uint8_t degreesVal[][2];


//======================================== Function prototypes =========================================================

int  CheckForSwitchPress(int oldTest, int test);
void DoDisplayTest();
void drawGauge(uint16_t x, uint16_t y, uint16_t r);
void drawNeedle(uint8_t index, uint16_t bcolor);
void drawPointerHelper(uint8_t index, int16_t val, uint16_t x, uint16_t y, uint16_t r, uint16_t color);
void EndOfTestMessage(int where);
#endif
