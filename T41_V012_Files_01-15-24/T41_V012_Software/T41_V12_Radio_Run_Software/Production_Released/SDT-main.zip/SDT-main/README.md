# T41-EP - 20W SSB and CW SDR Transceiver by Jack Purdum W8TEE and Al Peter AC8GY

## Source code changes by John Melton, G0ORX, to support:

### A subset of the Kenwood TS-2000 CAT interface
### G0ORX MCP23017 Front Panel
### G0ORX Rapsberry Pi Pico Front Panel

See https://github.com/g0orx/T41-EP/wiki

