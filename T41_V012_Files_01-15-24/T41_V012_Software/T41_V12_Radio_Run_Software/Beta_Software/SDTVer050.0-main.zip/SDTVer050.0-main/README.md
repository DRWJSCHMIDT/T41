# SDTVer050.0
Latest SDTVer050.0 with G0ORX MCP23017 Front Panel Code

MyConfigurationFile.h has define of G0ORX_FRONTPANEL.

Note this version has Bearing and BodePlotter disabled as I ran into some memory problems.

I will be updating the code to include the Kenwood TS-2000 CAT Interface and FM Mod/Demod in the next few days.
